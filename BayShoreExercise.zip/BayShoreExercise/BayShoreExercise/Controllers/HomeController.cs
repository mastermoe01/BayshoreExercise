﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BayShoreExercise.Models;
using System.Text;

namespace BayShoreExercise.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        //get action of exercise
        public ActionResult Exercise()
        {
            ViewBag.Message = "Exercise 1.";

            ExerciseModel m = new Models.ExerciseModel();

            return View(m);
        }

        //post action of exercise
        //has model passed in from the post
        [HttpPost]
        public ActionResult Exercise(ExerciseModel m)
        {
            //removes the state of the TextAmount so the value can be populated
            ModelState.Remove("TextAmount");

            //creates the string using the numToText function with the amount value passed in, .value is needed since it is a nullable decimal
            m.TextAmount = NumToText(m.Amount.Value);

            //returns the model to the view with the text amount set
            return View(m);
        }

        //creates the string to be shown using the passed in decimal
        public static string NumToText(decimal num)
        {
            //the string variable that will be returned as the end result of the function
            string numStr = string.Empty;

            //rounds to 2 decimal places
            num = decimal.Round(num, 2);

            //splits the number to whole and decimal parts
            string[] numArrStr = num.ToString().Split('.');
            long wholeNum = long.Parse(numArrStr[0]);
            string decStr;

            if (num.ToString().Contains("."))
                decStr = numArrStr[1];
            else
                decStr = "00";

            //creates the string for the cents or last end part of the string amount.
            string centsStr = string.Empty;
            centsStr = " and " + double.Parse((decStr.Length == 1 ? decStr + "0" : decStr)) + "/100 dollars.";

            if (wholeNum == 0)
            {
                numStr = "Zero" + centsStr;
                return numStr;
            }

            //number strings
            string[] ones = new string[] { "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };

            string[] tens = new string[] { "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };

            string[] powers = new string[] { "Thousand ", "Million ", "Billion " };

            //string builder for creating the whole number string
            StringBuilder WholeNumStr = new StringBuilder();

            //creates groups for ones, tens, hundreds, and thousands
            long[] groups = new long[] { 0, 0, 0, 0 };
            int groupIndex = 0;

            //keeps dividing by 1000 to get every grouping till no more groups
            while (wholeNum > 0)
            {
                groups[groupIndex++] = wholeNum % 1000;
                wholeNum /= 1000;
            }


            //for the 4 groups 3, 2, 1, 0 creates and appends the string builder in accordance to group and number
            for (int i = 3; i >= 0; i--)
            {
                int group = Convert.ToInt32(groups[i]);

                //hundreds
                if (group >= 100)
                {
                    WholeNumStr.Append(ones[group / 100 - 1] + " Hundred ");
                    group %= 100;

                    if (group == 0 && i > 0)
                        WholeNumStr.Append(powers[i - 1]);
                }

                //tens
                if (group >= 20)
                {
                    if ((group % 10) != 0)
                        WholeNumStr.Append(tens[group / 10 - 2] + " " + ones[group % 10 - 1] + " ");
                    else
                        WholeNumStr.Append(tens[group / 10 - 2] + " ");
                }
                else if (group > 0) // ones
                    WholeNumStr.Append(ones[group - 1] + " ");

                if (group != 0 && i > 0) //powers
                    WholeNumStr.Append(powers[i - 1]);
            }

            //creates the final string by combining the whole number string with the cents string to produce final result
            numStr = WholeNumStr.ToString().Trim() + centsStr;

            return numStr;
        }
    }
}