﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BayShoreExercise.Models
{
    public class ExerciseModel
    {
        //required number field that is nullable in order to first display textbox as null rather than default 0
        [Required]
        [Display(Name = "Amount in Numbers")]
        public decimal? Amount { get; set; }

        //field to be used to show the amount in text
        [Display(Name = "Amount in Text")]
        public string TextAmount { get; set; }
    }
}